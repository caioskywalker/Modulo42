package br.com.cfarias.vendas.online.errorhandling;

abstract class ApiSubError {

}
